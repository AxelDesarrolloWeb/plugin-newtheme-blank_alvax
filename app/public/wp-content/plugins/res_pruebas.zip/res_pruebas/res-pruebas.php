<?php 
/**
 * Plugin Name: pruebas
 * Plugin Uri: https://pruebas.com
 * Description: Este es un plugin de pruebas
 * Version: 1.0.0
 * Requires PHP: 8.2.27
 * Author: Alvax
 * Author Uri: https://alvax.eu
 * License: GPL V2
 * License Uri: https://www.gnu.org/licences/gpl-2.0.html
 * Text Domain: pruebas
 * Domain Path: /languages
 * */

function res_install() {
    //Accion
    require_once 'activador.php';
    

}

register_activation_hook( __FILE__, 'res_install' );
function res_disable() {
    //Accion
    flush_rewrite_rules(

    );
}

register_deactivation_hook(__FILE__, 'res_disable');